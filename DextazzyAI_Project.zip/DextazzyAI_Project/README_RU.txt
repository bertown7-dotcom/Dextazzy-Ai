# Dextazzy AI — проект для сборки APK

## Важно: сначала защити API-ключ
Ключ, который был вставлен в чат, следует отозвать/удалить в Google AI Studio и создать новый. Не публикуй ключ в открытом коде. В `main.py` вставь новый ключ вместо `ВСТАВЬ_НОВЫЙ_API_КЛЮЧ`.

## Что внутри
- `main.py` — приложение Kivy.
- `buildozer.spec` — настройки сборки Android APK.

## Как собрать APK бесплатно
Нужен Linux или Google Colab. На телефоне проще всего открыть Google Colab в браузере и запустить команды в ячейках.

1. Распакуй ZIP.
2. Загрузите `main.py` и `buildozer.spec` в рабочую среду Linux/Colab.
3. Установи Buildozer и зависимости:

```bash
!pip install buildozer cython==0.29.36
!sudo apt-get update
!sudo apt-get install -y git zip unzip openjdk-17-jdk autoconf libtool pkg-config \
  zlib1g-dev libncurses5-dev libncursesw5-dev libtinfo6 cmake libffi-dev libssl-dev
```

4. В каталоге, где лежат `main.py` и `buildozer.spec`, запусти:

```bash
!buildozer -v android debug
```

5. Первая сборка может занять много времени. После успешной сборки APK появится в папке `bin/`. Скачай APK на телефон и установи его. Android может попросить разрешить установку приложений из этого источника.

## Примечания
- Для сборки нужен интернет и несколько гигабайт свободного места.
- Модель задана как `gemini-2.5-flash`; доступность модели зависит от текущих настроек и поддержки API-ключа.
- API-ключ, встроенный в APK, можно извлечь. Для публичного приложения лучше использовать собственный сервер-посредник, а не хранить ключ в приложении.
